# Resilio sync

(formerly BitTorrent Sync) uses the BitTorrent protocol to sync files and folders between all of your devices. There are both free and paid versions, this container supports both. There is an official sync image but we created this one as it supports user mapping to simplify permissions for volumes.

---

**Homepage:** https://hub.docker.com/r/linuxserver/resilio-sync

**WebUI Port:** `8888`