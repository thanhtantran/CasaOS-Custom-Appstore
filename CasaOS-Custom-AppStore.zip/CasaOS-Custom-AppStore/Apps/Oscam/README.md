# Oscam

An Open Source Conditional Access Module software used for descrambling DVB transmissions using smart cards. It's both a server and a client.

---

**Homepage:** https://hub.docker.com/r/linuxserver/oscam

**WebUI Port:** `8888`