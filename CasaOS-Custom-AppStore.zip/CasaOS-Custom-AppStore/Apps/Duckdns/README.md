# Duckdns

A free service which will point a DNS (sub domains of duckdns. Org) to an IP of your choice. The service is completely free, and doesn't require reactivation or forum posts to maintain its existence.

---

**Homepage:** https://hub.docker.com/r/linuxserver/duckdns