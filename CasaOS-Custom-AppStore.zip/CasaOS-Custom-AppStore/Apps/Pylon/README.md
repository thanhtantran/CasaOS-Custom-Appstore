# Pylon

A web based integrated development environment built with Node. Js as a backend and with a supercharged JavaScript/HTML5 frontend, licensed under GPL version 3. This project originates from Cloud9 v2 project.

---

**Homepage:** https://hub.docker.com/r/linuxserver/pylon

**WebUI Port:** `3131`