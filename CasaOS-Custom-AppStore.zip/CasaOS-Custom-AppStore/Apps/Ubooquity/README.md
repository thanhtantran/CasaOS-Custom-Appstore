# Ubooquity

A free, lightweight and easy-to-use home server for your comics and ebooks. Use it to access your files from anywhere, with a tablet, an e-reader, a phone or a computer.

---

**Homepage:** https://hub.docker.com/r/linuxserver/ubooquity