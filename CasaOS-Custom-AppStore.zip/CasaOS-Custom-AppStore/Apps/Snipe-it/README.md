# Snipe it

Makes asset management easy. It was built by people solving real-world IT and asset management problems, and a solid UX has always been a top priority. Straightforward design and bulk actions mean getting things done faster.

---

**Homepage:** https://hub.docker.com/r/linuxserver/snipe-it

**WebUI Port:** `80`