# Mysql workbench

A unified visual tool for database architects, developers, and DBAs. MySQL Workbench provides data modeling, SQL development, and comprehensive administration tools for server configuration, user administration, backup, and much more.

---

**Homepage:** https://hub.docker.com/r/linuxserver/mysql-workbench

**WebUI Port:** `3000`