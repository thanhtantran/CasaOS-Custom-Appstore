# Radarr

A fork of Sonarr to work with movies à la Couchpotato.

---

**Homepage:** https://hub.docker.com/r/linuxserver/radarr

**WebUI Port:** `7878`