# Transmission

Designed for easy, powerful use. Transmission has the features you want from a BitTorrent client: encryption, a web interface, peer exchange, magnet links, DHT, µTP, UPnP and NAT-PMP port forwarding, webseed support, watch directories, tracker editing, global and per-torrent speed limits, and more.

---

**Homepage:** https://hub.docker.com/r/linuxserver/transmission

**WebUI Port:** `9091`