# Unrar

This container needs special attention. Please check https://hub. Docker. Com/r/linuxserver/unrar for details.

---

**WebUI Port:** `80`