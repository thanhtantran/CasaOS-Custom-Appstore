# Hedgedoc

Gives you access to all your files wherever you are. HedgeDoc is a real-time, multi-platform collaborative markdown note editor. This means that you can write notes with other people on your desktop, tablet or even on the phone. You can sign-in via multiple auth providers like Facebook, Twitter, GitHub and many more on the homepage.

---

**Homepage:** https://hub.docker.com/r/linuxserver/hedgedoc

**WebUI Port:** `3000`