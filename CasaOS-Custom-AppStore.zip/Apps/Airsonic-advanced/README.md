# Airsonic advanced

A free, web-based media streamer, providing ubiquitious access to your music. Use it to share your music with friends, or to listen to your own music while at work. You can stream to multiple players simultaneously, for instance to one player in your kitchen and another in your living room.

---

**Homepage:** https://hub.docker.com/r/linuxserver/airsonic-advanced

**WebUI Port:** `4040`