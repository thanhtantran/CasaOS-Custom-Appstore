# Emulatorjs

In browser web based emulation portable to nearly any device for many retro consoles. A mix of emulators is used between Libretro and EmulatorJS.

---

**WebUI Port:** `80`