# Freshrss

A free, self-hostable aggregator for rss feeds.

---

**Homepage:** https://hub.docker.com/r/linuxserver/freshrss

**WebUI Port:** `80`