# Tester

This internal tool is used as a desktop sandbox in our CI process to grab a screenshot of a hopefully functional endpoint

---