# Fail2ban

A daemon to ban hosts that cause multiple authentication errors.

---

**WebUI Port:** `80`