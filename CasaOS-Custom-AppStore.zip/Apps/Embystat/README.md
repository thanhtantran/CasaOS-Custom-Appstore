# Embystat

A personal web server that can calculate all kinds of statistics from your (local) Emby server. Just install this on your server and let him calculate all kinds of fun stuff.

---

**Homepage:** https://hub.docker.com/r/linuxserver/embystat

**WebUI Port:** `6555`