# Mariadb

One of the most popular database servers. Made by the original developers of MySQL.

---

**Homepage:** https://hub.docker.com/r/linuxserver/mariadb