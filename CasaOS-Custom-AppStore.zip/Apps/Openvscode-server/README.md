# Openvscode server

Provides a version of VS Code that runs a server on a remote machine and allows access through a modern web browser.

---