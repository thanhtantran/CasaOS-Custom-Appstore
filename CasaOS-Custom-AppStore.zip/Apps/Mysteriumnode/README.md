# Mysterium-node

MystNodes is a piece of software that can be downloaded onto your device, like a computer or Raspberry Pi, to provide a way for others to access the web safely and privately (such as through Mysterium VPN). Nodes are paid for the amount of traffic or bandwidth served through their device.

---

**WebUI Port:** `4449`