# Minisatip

A multi-threaded satip server version 1. 2 that runs under Linux and it was tested with DVB-S, DVB-S2, DVB-T, DVB-T2, DVB-C, DVB-C2, ATSC and ISDB-T cards.

---

**Homepage:** https://hub.docker.com/r/linuxserver/minisatip

**WebUI Port:** `8875`