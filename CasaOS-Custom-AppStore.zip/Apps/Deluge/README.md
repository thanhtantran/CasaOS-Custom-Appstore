# Deluge

A lightweight, Free Software, cross-platform BitTorrent client. * Full Encryption * WebUI * Plugin System * Much more. . .

---

**Homepage:** https://hub.docker.com/r/linuxserver/deluge

**WebUI Port:** `8112`