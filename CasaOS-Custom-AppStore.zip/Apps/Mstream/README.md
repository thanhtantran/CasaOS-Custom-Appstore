# Mstream

A personal music streaming server. You can use mStream to stream your music from your home computer to any device, anywhere. There are mobile apps available for both Android and iPhone.

---

**Homepage:** https://hub.docker.com/r/linuxserver/mstream

**WebUI Port:** `3000`