# Grav

A Fast, Simple, and Flexible, file-based Web-platform.

---

**Homepage:** https://hub.docker.com/r/linuxserver/grav

**WebUI Port:** `80`