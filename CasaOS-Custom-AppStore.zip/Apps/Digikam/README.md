# Digikam

digiKam: Professional Photo Management with the Power of Open Source

---

**Homepage:** https://hub.docker.com/r/linuxserver/digikam

**WebUI Port:** `3000`