# Pydio cells

The nextgen file sharing platform for organizations. It is a full rewrite of the Pydio project using the Go language following a micro-service architecture.

---

**Homepage:** https://hub.docker.com/r/linuxserver/pydio-cells

**WebUI Port:** `8080`