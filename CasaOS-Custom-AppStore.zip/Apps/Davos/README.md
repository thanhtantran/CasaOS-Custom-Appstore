# Davos

An FTP automation tool that periodically scans given host locations for new files. It can be configured for various purposes, including listening for specific files to appear in the host location, ready for it to download and then move, if required. It also supports completion notifications as well as downstream API calls, to further the workflow.

---

**Homepage:** https://hub.docker.com/r/linuxserver/davos

**WebUI Port:** `8080`