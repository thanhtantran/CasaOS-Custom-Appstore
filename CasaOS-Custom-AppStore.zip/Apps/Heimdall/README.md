# Heimdall

A way to organise all those links to your most used web sites and web applications in a simple way. Simplicity is the key to Heimdall. Why not use it as your browser start page. It even has the ability to include a search bar using either Google, Bing or DuckDuckGo.

---

**Homepage:** https://hub.docker.com/r/linuxserver/heimdall

**WebUI Port:** `80`