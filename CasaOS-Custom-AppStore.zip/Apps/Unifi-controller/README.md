# Unifi controller

The Unifi-controller software is a powerful, enterprise wireless software engine ideal for high-density client deployments requiring low latency and high uptime performance.

---

**Homepage:** https://hub.docker.com/r/linuxserver/unifi-controller

**WebUI Port:** `8080`