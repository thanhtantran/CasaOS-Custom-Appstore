# Mastodon

A free, open-source social network server based on ActivityPub where users can follow friends and discover new ones. .

---

**WebUI Port:** `80`