# Libreoffice

A free and powerful office suite, and a successor to OpenOffice. Org (commonly known as OpenOffice). Its clean interface and feature-rich tools help you unleash your creativity and enhance your productivity.

---

**Homepage:** https://hub.docker.com/r/linuxserver/libreoffice

**WebUI Port:** `3000`