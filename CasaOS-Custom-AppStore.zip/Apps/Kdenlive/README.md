# Kdenlive

A powerful free and open source cross-platform video editing program made by the KDE community. Feature rich and production ready.

---