# Prowlarr

A indexer manager/proxy built on the popular arr. Net/reactjs base stack to integrate with your various PVR apps. Prowlarr supports both Torrent Trackers and Usenet Indexers. It integrates seamlessly with Sonarr, Radarr, Lidarr, and Readarr offering complete management of your indexers with no per app Indexer setup required (we do it all).

---

**Homepage:** https://hub.docker.com/r/linuxserver/prowlarr

**WebUI Port:** `9696`