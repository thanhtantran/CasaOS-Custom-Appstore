# Limnoria

A robust, full-featured, and user/programmer-friendly Python IRC bot, with many existing plugins. Successor of the well-known Supybot.

---

**Homepage:** https://hub.docker.com/r/linuxserver/limnoria

**WebUI Port:** `8080`