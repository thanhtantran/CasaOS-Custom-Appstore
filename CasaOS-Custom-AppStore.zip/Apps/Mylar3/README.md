# Mylar3

An automated Comic Book downloader (cbr/cbz) for use with NZB and torrents written in python. It supports SABnzbd, NZBGET, and many torrent clients in addition to DDL.

---

**Homepage:** https://hub.docker.com/r/linuxserver/mylar3

**WebUI Port:** `8090`