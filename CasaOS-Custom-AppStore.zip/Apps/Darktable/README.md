# Darktable

An open source photography workflow application and raw developer. A virtual lighttable and darkroom for photographers. It manages your digital negatives in a database, lets you view them through a zoomable lighttable and enables you to develop raw images and enhance them.

---

**Homepage:** https://hub.docker.com/r/linuxserver/darktable

**WebUI Port:** `3000`