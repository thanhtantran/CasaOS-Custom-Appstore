# Pwndrop

A self-deployable file hosting service for sending out red teaming payloads or securely sharing your private files over HTTP and WebDAV.

---

**Homepage:** https://hub.docker.com/r/linuxserver/pwndrop

**WebUI Port:** `8080`