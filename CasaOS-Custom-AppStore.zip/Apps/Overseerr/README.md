# Overseerr

A request management and media discovery tool built to work with your existing Plex ecosystem.

---

**Homepage:** https://hub.docker.com/r/linuxserver/overseerr

**WebUI Port:** `5055`