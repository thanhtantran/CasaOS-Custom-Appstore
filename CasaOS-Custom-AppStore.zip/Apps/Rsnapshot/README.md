# Rsnapshot

A filesystem snapshot utility based on rsync. Rsnapshot makes it easy to make periodic snapshots of local machines, and remote machines over ssh. The code makes extensive use of hard links whenever possible, to greatly reduce the disk space required. '

---

**Homepage:** https://hub.docker.com/r/linuxserver/rsnapshot

**WebUI Port:** `80`