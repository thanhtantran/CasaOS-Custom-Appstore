# Domoticz

A Home Automation System that lets you monitor and configure various devices like: Lights, Switches, various sensors/meters like Temperature, Rain, Wind, UV, Electra, Gas, Water and much more. Notifications/Alerts can be sent to any mobile device.

---

**Homepage:** https://hub.docker.com/r/linuxserver/domoticz

**WebUI Port:** `8080`