# Calibre web

A web app providing a clean interface for browsing, reading and downloading eBooks using an existing Calibre database. It is also possible to integrate google drive and edit metadata and your calibre library through the app itself. This software is a fork of library and licensed under the GPL v3 License.

---

**Homepage:** https://hub.docker.com/r/linuxserver/calibre-web

**WebUI Port:** `8083`