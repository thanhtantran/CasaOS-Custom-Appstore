# Sabnzbd

Makes Usenet as simple and streamlined as possible by automating everything we can. All you have to do is add an. Nzb. SABnzbd takes over from there, where it will be automatically downloaded, verified, repaired, extracted and filed away with zero human interaction.

---

**Homepage:** https://hub.docker.com/r/linuxserver/sabnzbd

**WebUI Port:** `8080`