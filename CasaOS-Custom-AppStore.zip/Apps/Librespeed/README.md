# Librespeed

A very lightweight Speedtest implemented in Javascript, using XMLHttpRequest and Web Workers. No Flash, No Java, No Websocket, No Bullshit.

---

**Homepage:** https://hub.docker.com/r/linuxserver/librespeed

**WebUI Port:** `80`