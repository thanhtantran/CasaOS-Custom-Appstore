# Quassel web

A web client for Quassel. Note that a Quassel-Core instance is required, we have a container available here.

---

**Homepage:** https://hub.docker.com/r/linuxserver/quassel-web

**WebUI Port:** `64080`