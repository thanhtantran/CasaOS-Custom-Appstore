# Firefox

Browser, also known as Mozilla Firefox or simply Firefox, is a free and open-source web browser developed by the Mozilla Foundation and its subsidiary, the Mozilla Corporation. Firefox uses the Gecko layout engine to render web pages, which implements current and anticipated web standards.

---

**Homepage:** https://hub.docker.com/r/linuxserver/firefox

**WebUI Port:** `3000`