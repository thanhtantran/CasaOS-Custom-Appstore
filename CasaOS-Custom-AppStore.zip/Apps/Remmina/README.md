# Remmina

A remote desktop client written in GTK, aiming to be useful for system administrators and travellers, who need to work with lots of remote computers in front of either large or tiny screens. Remmina supports multiple network protocols, in an integrated and consistent user interface. Currently RDP, VNC, SPICE, NX, XDMCP, SSH and EXEC are supported.

---

**Homepage:** https://hub.docker.com/r/linuxserver/remmina

**WebUI Port:** `3000`